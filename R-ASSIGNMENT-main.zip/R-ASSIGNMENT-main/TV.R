#IMPORTING LIBRARIES
library(rvest)
library(robotstxt)
library(stringr)
library(dplyr)

#SCRAPING WEBSITE
url <- "https://www.flipkart.com/search?count=40&otracker=CLP_filters&p%5B%5D=facets.smart_tv%255B%255D%3DYes&p%5B%5D=facets.resolution%255B%255D%3DUltra%2BHD%2B%25284K%2529&sid=ckf%2Fczl&otracker=nmenu_sub_TVs%20and%20Appliances_0_Smart%20and%20Ultra%20HD&otracker=nmenu_sub_TVs%20%26%20Appliances_0_Smart%20%26%20Ultra%20HD"

#ALLOWBILITY 
path = paths_allowed(url)

#HTML FROM THE WEBSITE
web = read_html(url)
View(web)

#SEGREGATING NAME
names <- web %>% html_nodes(".KzDlHZ") %>% html_text()
View(names)

#SEGREGATING PRICE
price <- web %>% html_nodes(".cn\\+\\+Ap") %>% html_text()
View(price)

#SEGREGATING OPERATING SYSTEM
os <- web %>% html_nodes(".cn\\+\\+Ap") %>% html_text()
View(os)

#SEGREGATING LAUNCH YEAR
year <- web %>% html_nodes(".cn\\+\\+Ap") %>% html_text()
View(year)

#SEGREGATING RATING
rating <- web %>% html_nodes(".cn\\+\\+Ap") %>% html_text()
View(rating)

#SEGREGATING WARRANTY
warranty <- web %>% html_nodes(".cn\\+\\+Ap") %>% html_text()
View(warranty)

#CREATING DATA FRAME
smartTV = data.frame(names, price, os, year, rating, warranty)
View(smartTV)

#SAVING A CSV FILE
write.csv(smartTV,"filpkart_smart TV.csv")

